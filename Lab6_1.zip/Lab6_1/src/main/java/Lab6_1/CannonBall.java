/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab6_1 ;
/**
 *
 * @author Maou
 */
class CannonBall {
    private double S,SS,DS,T,DT,N,V0 ;
    private double initV; 
    private double simS;
    private double simT;
    public static final double g = 9.81 ;
    public CannonBall (int V) {
        initV = V ;
        V0 = V ;
    }
    public void simulatedFlight(){
        N = 0 ;
        while (initV > 0){
            DS = initV*0.01 ;
            S = S + DS ;
            initV = initV-(g*0.01);
            N = N+1;
            if (initV < 0){
                System.out.printf("Final distance: %.3f",S ); 
                System.out.printf("  Total time: %.2f\n",(N/100));
                break ;
            }
            if ((N%100) == 0 ){
                System.out.printf("Distance on %.0f",(N/100));//+" sec: "+"%.3f\n",S );
                System.out.printf(" sec: %.3f\n",S);
            }
        
        }
    }
    public double getSimulatedTime() {
        T = N/100 ;
        return T ;
    }
    public double calculusFlight(double t){
        SS = (-0.5*g*t*t) + (V0*t) ;
        return SS ;
    }
    public double getSimulatedDistance(){
        return S ;
    }
}
