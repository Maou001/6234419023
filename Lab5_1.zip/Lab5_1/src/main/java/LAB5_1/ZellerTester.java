/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB5_1 ;
import java.util.Scanner;
/**
 *
 * @author ADMIN
 */
public class ZellerTester {
    public static void main (String [] args ) {
        Scanner s1 = new Scanner(System.in) ;
        System.out.println("Enter year (e.g., 2012): ");
        int Y = s1.nextInt();
        System.out.println("Enter month (1-12): ");
        int M = s1.nextInt();
        System.out.println("Enter day of the month (1-31): ");
        int D = s1.nextInt();
        Zeller z = new Zeller (Y,M,D);
        System.out.println("Day of the week is " + z.getDayofweek().getDayValue());   
    } 
    
}
