/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB5_1 ;
import java.util.Scanner;
/**
 *
 * @author ADMIN
 */

//enum Day
//{
//    SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
//    public final String dayName;
//    private final String dayValue;
//    Day(String dayInput){
//        dayName = dayInput;
//        dayValue = dayInput;
//    }
//    public String getDayValue(){
//        return dayValue ;
//    }
//}

public class Zeller {
    private int h,q,m,j,k,y ;
    private int dayOfMonth ; 
    private int month ; 
    private int year ; 
public Zeller (int Y,int M,int D){
    month = M ;
    if(M <= 2)
    {
        m = M + 12;
        Y = Y - 1;
    }
    dayOfMonth = D ;
    year = Y ;
    q = D ;
    j = Y/100 ;
    k = Y%100 ;
    }
enum Day
{
    SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
    public final String dayName;
    private final String dayValue;
    Day(String dayInput){
        dayName = dayInput;
        dayValue = dayInput;
    }
    public String getDayValue(){
        return dayValue ;
    }
}
public Day getDayofweek() 
{
    Day dOutput = Day.SUNDAY;
    h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(j*5))%7;
    switch(h)
    {
    case 1: dOutput =Day.SUNDAY; break;
    case 2: dOutput =Day.MONDAY; break;
    case 3: dOutput =Day.TUESDAY; break;
    case 4: dOutput =Day.WEDNESDAY; break;
    case 5: dOutput =Day.THURSDAY; break;
    case 6: dOutput =Day.FRIDAY; break;
    case 0: dOutput =Day.SATURDAY; break;
    }
    return dOutput;
}
}

        
        
        

    

