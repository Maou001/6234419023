/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;

/**
 *
 * @author usci
 */
public class InsectPopulation {    
    private double breed,spay,insect,ccc;
    public InsectPopulation (float X ) {
        ccc =  X ;
    }
    //public void Constructor(float constructor) throws IllegalArgumentException{
    //    if(constructor>0){this.constructor = constructor;
    //    }else{
    //        throw new IllegalArgumentException("Error constructor < 0 ") ;
    //    }
    //}
    public void breed () {
        ccc = ccc*2 ;
    }
    public void spay(){
        ccc = ccc*0.9;
    }
    public double  getNumInsect () {
        
        return ccc;
    }
    
}
