/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class PurseTester {
    public static void main(String[] args) {
        Purse Purse1 = new Purse();
        Purse1.addCoin("Quarter");
        Purse1.addCoin("Dime");
        Purse1.addCoin("Nickel");
        Purse1.addCoin("Dime");
        System.out.println("Purse1 "+Purse1.toString());
        Purse1.reverse();
        System.out.println("Purse1 reverse "+Purse1.toString());
        Purse Purse2 = new Purse();
        Purse2.addCoin("Nickel");
        Purse2.addCoin("Quarter");
        Purse2.addCoin("Dime");
        System.out.println("Purse2 "+Purse2.toString());
        System.out.println("same contents :"+Purse1.sameContents(Purse2)); 
        System.out.println("same coin :" +Purse1.sameCoin(Purse2));
        System.out.println("Tranfer Purse");
        Purse1.transfer(Purse2);
        System.out.println("Purse1 "+Purse1.toString());
        System.out.println("Purse2 "+Purse2.toString());
    }
    
}
