
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class MagicSquareTester {
    public static void main(String[] args) {
        System.out.print("Enter odd number:");
        Scanner s = new Scanner(System.in);
        int num = s.nextInt();
        while(num%2 == 0){
            System.out.print("Enter odd number:");
            num = s.nextInt();
        }
        MagicSquare S = new MagicSquare(num);
        System.out.println(S.toString());
        
    }
}
