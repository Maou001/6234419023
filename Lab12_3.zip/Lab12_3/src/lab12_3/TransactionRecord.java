/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author ADMIN
 */
public class  TransactionRecord  {
    private int accountNo ;
    private double amountOfTransaction ;
    public TransactionRecord(int accountNo, double amountOfTransaction){
        setAccountNo(accountNo);
        setAmountOfTransaction(amountOfTransaction);
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo ;
    }

    public void setAmountOfTransaction(double amountOfTransaction) {
        this.amountOfTransaction = amountOfTransaction ;
    }
    public int getAccountNo(int accountNo) {
        return accountNo ;
    }
    public double getAmountOfTransaction(double amountOfTransaction) {
        return amountOfTransaction ;
    }
    
}
