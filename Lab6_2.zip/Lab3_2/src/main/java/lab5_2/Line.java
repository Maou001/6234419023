/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;

/**
 *
 * @author supan
 */
public class Line {
    private double m,b,x;
    public Line(double x,double y, double m){
        this.x = Double.NaN;
        this.m = m;
        this.b = (m*(-x))+y;
    }
    public Line(double x1,double y1,double x2, double y2){
        this.m = (y2-y1)/(x2-x1);
        this.x = Double.NaN;
        this.b = (m*(-x1))+y1;
    }
    public Line(double m,double b){
        this.x = Double.NaN;
        this.m = m;
        this.b = b;

    }
    public Line(double a){
        this.x = a;
        this.m = Double.NaN;
        this.b = Double.NaN;

    }
    public boolean isParallel(Line line){
        boolean check = false;
        if(Double.isNaN(this.m)&Double.isNaN(line.m)){
            check = true;
        }else check = this.m == line.m;
        return check;
    }
    public boolean equals(Line line){
        boolean check = false;
        if(this.x == line.x){
            check = true;
        }else check = this.m == line.m & this.b == line.b;
        
        return check;
    }
    public boolean isIntersect(Line line){
        //this.m != line.m
        return !this.isParallel(line);
    }

    public Point2D.Double getIntersectionPoint(Line line){
        double PointX = 0;
        double PointY = 0;
        Point2D.Double l = new Point2D.Double();
        if(Double.isNaN(line.m) & Double.isNaN(line.b)){
            PointX = line.x;
            PointY = (this.m*PointX)+this.b;
            l.setLocation(PointX, PointY);                  
        }else if(Double.isNaN(line.x) & Double.isNaN(this.x)){
            PointX = (line.b-this.b)/(this.m-line.m);
            PointY = (this.m*PointX)+this.b;
            l.setLocation(PointX, PointY);
        }else if (Double.isNaN(this.m) & Double.isNaN(this.b)){
            PointX = this.x;
            PointY = (line.m*PointX)+line.b;
            l.setLocation(PointX, PointY);
            
           
        }
        return l;
    }
    //un-indent shift+tab
	   
}
