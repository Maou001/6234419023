/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class Question {
    public String  text,answer ; 
    public Question(){
        
    }
    public Question(String text){
        setText(text);
    }
    public void setText(String text){
        this.text = text;
    }
    public String getText(){
        return text;
    }
     public void setAnswer(String answer){
        this.answer = answer;
    }
    public String getAnswer(){
        return answer;
    }
     public boolean checkAnswer(String response){
        return response.equals(getAnswer());
    }
     public void display(){
        System.out.println(getText());
    }


}
