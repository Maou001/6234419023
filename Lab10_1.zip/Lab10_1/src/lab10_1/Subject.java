/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author ADMIN
 */
public class Subject  implements Evaluation {
    private String subjName ;
    private int[] score ;
    public Subject(String subjName,int[] score){
        this.setSubjName(subjName);
        this.setScore(score);
    }


    @Override
    public double evaluate() {
        int cnt = 0 ;
         for(int i: this.getScore()){
            cnt += i ;
        }
        return cnt/2 ; 
    }

    @Override
    public char grade(double score) {
        char i = 'F' ;
        if (score >= 70 ){
            i = 'P' ;
        }
        return i ;
    }

    private void setSubjName(String subjName) {
        this.subjName = subjName ;
        
    }
    public String getSubjName() {
        return subjName;
    }
    private void setScore(int[] score) {
        this.score = score ;
        
    }

    private int[] getScore() {
        return score ;
    }
    @Override
    public String toString(){
        return this.getSubjName();
    }

    
}
