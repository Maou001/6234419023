
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class TimeIntervalTester {
    public static void main (String[]args){
        Scanner S1 = new Scanner (System.in );
        System.out.println("Enter start time : ") ;
        int s = S1.nextInt() ;
        System.out.println("Enter end time : ") ;
        int ss = S1.nextInt() ;
        TimeInterval t1 = new  TimeInterval(s,ss) ; 
        System.out.printf(t1.getHours()+" hours "+t1.getMinutes()+" minute") ;
    }
    
}
