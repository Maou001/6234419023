/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

import java.util.Scanner;

/**
 *
 * @author usci
 */
public class SodaTester {
    public static void main (String[]args){
        Scanner t = new Scanner (System.in) ; 
        //Scanner t2 = new Scanner (System.in) ; 
        System.out.print("Enter height: ");
        int t1=t.nextInt();
        System.out.print("Enter diameter: ");
        int t2=t.nextInt();
        SodaCan s1 = new SodaCan(t1,t2) ;
        System.out.printf("Volume: %.2f",s1.getVolume());
        System.out.printf("\nSurface area: %.2f",s1.getSurfaceArea());
        
    }
    
}
