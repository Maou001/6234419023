/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3_2;

/**
 *
 * @author Maou
 */
public class LetterPrinter {
    public static void main (String[]args){
        Letter l1 = new Letter ("Jade","Clarissa") ;
        l1.addLine("We must find Simon quickly.");
        l1.addLine("He might be in danger.");
    System.out.println(l1.getText());
    }
    
}
