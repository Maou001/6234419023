package com.mycompany.lab3_3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class CashRegister {   
    public double input,total,fee ;
    public CashRegister(double amt){
        fee = amt;
    }
    public void recordPurchase(double amount){
        total = total + amount ;
    }
    public void recordTaxablePurchase(double amt){
        total = total+amt*((100+fee)/100);
    }
    public double getTotalTax (){
        double tax = total*(fee/100);
        return tax ;
    }
    public void enterPayment (double amt){
        input = input+amt ;
    }
    public double giveChange (){
        double change = input-total ;
        input = 0;
        total = 0;
        return change ;
    }
         
}
