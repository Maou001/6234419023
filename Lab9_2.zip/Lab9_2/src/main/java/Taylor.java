/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab9_2 ;
/**
 *
 * @author ADMIN
 */
public abstract class Taylor {
            private int k ;
            private double x ;
            public int factorial(int n){
                        int f = 1;
                        while (n > 0){
                                   f = f*n;
                                    n = n-1 ;
                        }
                        return f ;
            }
            public void setIter(int k) {
                        this.k=k;
            }
            public int getIter() {
                        return k ;
            }
            public void setValue(double x){
                        this.x=x;
            }
            public double getValue() {
                        return x ;
            }
            public abstract void printValue() ;
            public abstract double getApprox() ;
}
