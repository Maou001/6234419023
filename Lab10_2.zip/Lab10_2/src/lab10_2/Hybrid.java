/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *45,1.2,x,150,1
 * @author ADMIN
 */
public class Hybrid extends Bus implements LiquidFuel,Electric {
    private double voltage;
    private double range;
    private int emissionTier;
    public Hybrid(int capacity, double cost,int voltage,int range,int emissionTier) {
        super(capacity, cost);
        this.setRange(range);
        this.setEmissionTier(emissionTier);
        this.setVoltage(voltage);
    }

    private void setRange(double range) {
        this.range = range ;
    }

    private void setEmissionTier(int emissionTier) {
        this.emissionTier = emissionTier ;
    }

    private void setVoltage(double voltage) {
        if (voltage < LOW_VOLTAGE ){
            this.voltage = LOW_VOLTAGE ;
        }
        else if (voltage > HIGH_VOLTAGE ){
            this.voltage = HIGH_VOLTAGE ;
        }
        else {
            this.voltage = voltage ;
        }
    }

    @Override
    public double getRange() {
        return this.range ;
    }
    
    @Override
    public int getEmissionTier() {
        return this.emissionTier ;
    }

    @Override
    public double getVoltage() {
        return this.voltage ;
    }
    
    @Override
    public double getAccel() {
        return 4.0;
    }

}