/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab6_3 ;

import java.util.Random;

/**
 *
 * @author Maou
 */
public class CityGrid {
    private int X,Y;
    private int xCoor ;
    private int yCoor;
    private int gridSize;
    public CityGrid (int x,int y) {
        gridSize = X*Y;
        xCoor = x/2 ;
        yCoor = y/2 ; 
        X = x ;
        Y = y ;
    }
    public void walk(){
        Random ran = new Random();
        int w = ran.nextInt(4);
        switch(w){
            case 0 : xCoor++;break;
            case 1 : xCoor--;break;
            case 2 : yCoor++;break;
            case 3 : yCoor--;break;
        }
    }
    public boolean isInCity(){
        if ((xCoor<0 || xCoor>X) || (yCoor<0 || yCoor>Y )) {
        return false ;
        }else{ 
            return true ;
        }
    }
    public void reset(){
        xCoor=X/2;
        yCoor=Y/2;
    }
}
