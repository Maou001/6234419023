/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1 ;
/**
 *
 * @author ADMIN
 */
public class Car {
    public double G,EF ;
    public Car (double G , double EF ) {
        setGas(G);
        this.EF = EF ;
    }
    public void drive(double distance){
        double UG =  distance/EF ;
        if (UG > G ){
            System.out.println("You cannot drive too far, please add gas");
        }else{
            G = G - UG ;
        } 
    }
    public void setGas(double amount){
        this.G = amount ;
    }
    public double getGas(){
        return G ;
    }
    public double getEfficiency(){
        return EF ;
    }
    public void addGas(double amount) {
        G = G + amount ;
    }
}
