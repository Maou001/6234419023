/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Lab12_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(System.in);
        File f = new File("wordlist.txt");
        ArrayList<String> w = new ArrayList<>();
        try{
            Scanner wl = new Scanner(f);
            String wll = wl.nextLine();
            while(wl.hasNextLine()){
                w.add(wll);
                
            
            }
            System.out.print("Enter a sentence: ");
            String[] input = sc.nextLine().split(" ");
            System.out.println("Words not contained: ");
            for (String i : input ){
                for(String j : w ){
                    int n =0;
                    int ccc = w.size() ;
                    if (!i.equals(j)){
                        ccc -= 1 ;
                        if(ccc == 1){
                        System.out.print(i);
                        }
                    }else{
                        n+=1; 
                        if (n == input.length){
                        System.out.print("N/A");
                        }
                    }
                    
                }
            }
             wl.close();

        
        }catch(IOException e){
            System.out.println(e);
        }   
    }
}
