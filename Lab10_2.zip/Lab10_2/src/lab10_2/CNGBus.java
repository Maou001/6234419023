/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * 50,1,200,2
 * @author ADMIN
 */
public class CNGBus extends Bus implements LiquidFuel {
    private double range;
    private int emissionTier;

    public CNGBus(int capacity, double cost,double range,int emissionTier){
        super(capacity, cost);
        this.setRange(range);
        this.setEmissionTier(emissionTier);

    }

    @Override
    public double getRange() {
        return this.range ;
    }

    @Override
    public int getEmissionTier() {
        return this.emissionTier ;
    }

    private void setRange(double range) {
        this.range = range ;
    }

    private void setEmissionTier(int emissionTier) {
        this.emissionTier = emissionTier ;
    }
    @Override
    public double getAccel() {
        return 3.0;
    }

    
}
