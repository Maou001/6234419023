/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB9_1 ; 
/**
 *
 * @author ADMIN
 */
public class Pizza {
            private String name;
            private double price;
            public Pizza(String name,double price){
                        this.name = name;
                        this.price = price;
            }
            public double getPrice(){
                        return price;
            }
            public String getMenu(){
                        return name;
            }
            public String getSpecial(){
                        return "";
            }
}

    

