/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1 ;
/**
 *
 * @author ADMIN
 */
public class Truck extends Car {
    public double M,W;
    public Truck(double G, double EF , double M , double W) {
        super(G, EF);
        if (W > M ) {
            this.W = M ;
        }else{
            this.W = W ;
        }
    }
    @Override 
    public void drive(double distance){
        double UG =  distance/getEfficiency()  ;
        if (W < 1){
            UG = distance/getEfficiency() ;
        }else if ( 1 <= W && W <= 10) {
            UG = (distance/getEfficiency())*1.1 ;
        }else if ( 11 <= W && W <= 20) {
            UG = (distance/getEfficiency())*1.2 ;
        }else if ( 20 < W ) {
            UG = (distance/getEfficiency())*1.3 ;
        }
        if (UG > getGas() ) {
            System.out.println("You cannot drive too far, please add gas");
        }else{
            setGas(getGas()-UG) ;
            //G = G - UG ;
        }
    }
}
