
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class Purse {
    private ArrayList<String> L = new ArrayList<String>() ;
    private int nickel,dime,quarter;
    public void addCoin(String coinName){
        L.add(coinName);   
    }
    public String toString(){
        return (""+L) ;
    }
    public ArrayList<String> reverse(){
        ArrayList<String> RV = new ArrayList<>();
        for (int i = 1 ; i <= L.size() ; i++){
            int n = L.size() - i ;
            RV.add(L.get(n));
        }

        L = RV;
        return RV ;
    }
    public void transfer(Purse P2){
        for (int i = 0; i < L.size() ; i++)  {
            P2.addCoin(L.get(0));
            L.remove(0);
        }
    }
    public boolean sameContents(Purse other){
        boolean c = false;
        if(L.size()==other.L.size()){
            for(int i = 0 ; i< L.size();i++){
                if(L.get(i).equals(other.L.get(i))) {
                    c = true;
                }else{ 
                    c = false ; break;
                }     
            } 
        }
        return c ;
    }
    public boolean sameCoin(Purse P2){
        for(int i = 0 ; i < L.size();i++){
            switch(L.get(i)){
                case "Nickle" : this.nickel+=1;
                case "Dime" : this.dime +=1;
                case "Quarter" : this.quarter +=1;
            }
        }
        for(int i = 0 ; i < P2.L.size();i++){
            switch(P2.L.get(i)){
                case "Nickle" : P2.nickel+=1;
                case "Dime" : P2.dime +=1;
                case "Quarter" : P2.quarter +=1;
            }
        }
        boolean c = this.nickel == P2.nickel && this.dime == P2.dime&& this.quarter == P2.quarter;
        return c ;
    }
}

    

