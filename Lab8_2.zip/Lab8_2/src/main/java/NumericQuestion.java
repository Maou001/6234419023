/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.math.BigDecimal;
import java.math.RoundingMode;
/**
 *
 * @author ADMIN
 */
public class NumericQuestion extends Question {
    
    public NumericQuestion(String text) {
        super(text);
    }
@Override
    public boolean checkAnswer(String response){
        double doubleResponse = Double.parseDouble(response);
        double doubleAnswer = Double.parseDouble(getAnswer());
        if (Math.abs(round4(doubleAnswer-doubleResponse)) <= 0.01) {
            //()
            return true;
        }
        return false;
    }
    private Double round4 (Double val) {
        return new BigDecimal(val.toString()).setScale(4,RoundingMode.HALF_UP).doubleValue();
    }
    
}
