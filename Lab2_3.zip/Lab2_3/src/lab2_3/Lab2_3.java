/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author usci
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar(2020,Calendar.JANUARY, 20);
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.FEBRUARY, 1);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+(month+1)+" "+year);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth1 = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month1 = myBirthday.get(Calendar.MONTH);
        int year1 = myBirthday.get(Calendar.YEAR);
        int weekday1 = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday1+" "+dayOfMonth1+" "+(month1+1)+" "+year1);
        // TODO code application logic here
    }
    
}
