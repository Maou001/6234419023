/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class Sequential {
    public static void main(String[] args) throws IOException{
        Scanner sc = new Scanner(System.in);
        PrintWriter w = new PrintWriter("text.txt");
        String line = sc.nextLine();
         while(!line.equals("quit")){
            w.println(line);
            line = sc.nextLine();
        }
        w.print(line);
        w.close();
        File f = new File("text.txt");
        Scanner rf = new Scanner(f);
        ArrayList<String> ww = new ArrayList<>();
        String a = null;
        String b = null;
        String nl = rf.nextLine() ;
        int nc = 0 ;
        int nL = 0 ;
        while(!nl.equals("quit")){
             for(int i= 0; i<nl.length(); i++){
                nc++;
            nL++;     
            }
        }
        String[] WW = nl.split(" ");
            for(String i : WW){
                ww.add(i);
            }
        rf.close();
        System.out.println("Total characters : "+ nc );
        System.out.println("Total words : "+ww.size());
        System.out.println("Total lines : "+nL);
        

        
    }
    //โปรแกรมมันรันไม่จบสักทีไม่เข้าใจเหมือนกันว่าทำไม แต่ไม่ได้รัน



    
    
    
}
