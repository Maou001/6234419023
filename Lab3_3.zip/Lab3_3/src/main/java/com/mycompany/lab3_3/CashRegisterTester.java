/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3_3;

import java.io.PrintStream;

/**
 *
 * @author Maou
 */
public class CashRegisterTester {
    public static void main (String[]args){
    CashRegister c = new CashRegister (10) ;
    c.recordPurchase(50);
    c.recordPurchase(40);
    c.recordTaxablePurchase(30);
    c.enterPayment(1000);
    System.out.printf("Your change "+c.giveChange());
    }
    
}
