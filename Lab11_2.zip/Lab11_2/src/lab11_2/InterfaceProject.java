/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_2;

import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class InterfaceProject {
    public static void main(String[] args) {
        Ground ground1 = new Ground("Bangkok Ground");
        Pool pool1 = new Pool("Chula swimming pool");
        Sky sky1 = new Sky("Japan Sky");
        System.out.println("**************1*************");
        Fish fish1 = new Fish("Nemo");
        fish1.swim(ground1);
        fish1.swim(pool1);
        fish1.swim(sky1);
        System.out.println("****************************");
        Cat cat1 = new Cat("Jee");
        System.out.println("**************2*************");
        cat1.walk(ground1);
        cat1.walk(pool1);
        cat1.walk(sky1);
        System.out.println("****************************");
        Bird bird1 = new Bird("Crow");
        bird1.walk(ground1);
        bird1.walk(pool1);
        bird1.walk(sky1);
        bird1.run(ground1);
        bird1.run(pool1);
        bird1.run(sky1);
        bird1.fly(ground1);
        bird1.fly(pool1);
        bird1.fly(sky1);
        System.out.println("****************************");
        ArrayList<Terrain>  Terrain = new ArrayList<>() ;
        Terrain.add(ground1);
        Terrain.add(pool1);
        Terrain.add(sky1);
        ArrayList <Animal> Animal = new ArrayList<>();
        Animal.add(cat1);
        Animal.add(fish1);
        Animal.add(bird1);
        System.out.println("**************4*************");
        for(Animal animal:Animal) {
            for(Terrain terrain:Terrain) {
                if (animal instanceof CanWalk) {
                    ((CanWalk) animal).walk(terrain);
                    ((CanWalk) animal).run(terrain);
                }
                if (animal instanceof CanSwim) {
                    ((CanSwim) animal).swim(terrain);
                }
                if (animal instanceof CanFly) {
                    ((CanFly) animal).fly(terrain);
                } 
            }
            System.out.println("****************************");
        } 
    }
}
