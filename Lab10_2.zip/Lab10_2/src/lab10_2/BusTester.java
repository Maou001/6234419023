/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class BusTester {
     public static void main(String[] args) {
         ArrayList<Bus> arr = new ArrayList<>();
         Hybrid h = new Hybrid(45,1.2,600,150,1);  //45,1.2,x,150,1
         CNGBus c = new CNGBus(50,1,200,2); //50,1,200,2
         arr.add(h);
         arr.add(c);
         for ( Bus b:arr ) {
             System.out.print("ID: " + b.getID() + "\n" + "Emission Tier: ");
            if(b instanceof CNGBus){
                CNGBus cb = (CNGBus) b; //cast super -> sub
                System.out.println(cb.getEmissionTier());
            }else if(b instanceof Hybrid) {
                Hybrid hb = (Hybrid) b;
                System.out.println(hb.getEmissionTier());
            }
            System.out.println("Accel: "+b.getAccel());
         
         }


     }
     

    
}
