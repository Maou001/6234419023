/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class TimeInterval  {
    private int ST,STH,STM,ET,ETH,ETM ;
    public TimeInterval (int x,int y) {
        STH = (x/100)*60 ;
        STM = x%100 ;
        ST = STH+STM ;
        ETH = (y/100)*60 ;
        ETM = y%100 ;
        ET = ETH+ETM ;
    }
    public int getHours () {
        return  (ET - ST)/60 ; 
    } 
    public int getMinutes () {
        return (ET-ST)%60 ;
    }
    
}
