///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.mycompany.lab3_2;
//
///**
// *
// * @author Maou
// */
//public class Letter { 
//    private String allText,f1,t1,fin ;
//    public Letter(String from, String to) {
//        f1 = from ;
//        t1 = to ;
//        allText = "" ;
//    }
//    public void addLine(String line){
//        allText = "\n"+allText+line+"\n";
//        
//    }
//    public String getText() {
//        fin = "Dear " + t1 + allText+ "\n" + "Sincerely," + "\n" +f1 ;
//    return fin ;
//    }
//    
//}
