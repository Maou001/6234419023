/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class MusicBox  implements SimpleQueue {
     private ArrayList<Object> Q = new ArrayList<>();
     
    @Override
    public void enqueue(Object o) {
        Q.add(o) ;
        System.out.print(o + " is added in queue");
    }

    @Override
    public void dequeue() {
        if(Q.size() == 0){
            System.out.println("Not have music in queue");
        }else{
            System.out.println("Now playing "+Q.get(0));
            Q.remove(0);
        }
    }
    
}
