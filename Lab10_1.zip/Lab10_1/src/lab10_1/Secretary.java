/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author ADMIN
 */
public class Secretary extends Employee implements Evaluation {
    private int typingSpeed ;
    private int[] score ;

    public Secretary(String name, int salary,int[] score,int typingSpeed) {
        super(name, salary);
        this.setTyping(typingSpeed);
        this.setScore(score);         

    }

//    Secretary(String sasipa, int i, int[] sc, int i0) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    @Override
    public double evaluate() {
        int cnt = 0 ;
         for(int i: this.getScore()){
            cnt += i ;
        }
        return cnt ; 
    }

    @Override
    public char grade(double score) {
        char i = 'F' ;
        if (score >= 90 ){
            this.setSalary(18000);
            i = 'P' ;
        }
        return i ;
    }

    public int getTyping() {
        return typingSpeed;
    }

    private void setTyping(int typingSpeed) {
        this.typingSpeed = typingSpeed ;
    }

    private void setScore(int[] score) {
        this.score = score ;
    }
    public int[] getScore(){
        return score ;
    }
    
}
