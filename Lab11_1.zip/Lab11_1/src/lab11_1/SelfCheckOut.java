/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author ADMIN
 */
public class SelfCheckOut implements SimpleQueue {
    private ArrayList<Object> Q = new ArrayList<>();
    private double amount;
    
    @Override
    public void enqueue(Object o) {
        
         if(o instanceof Product){
           System.out.println(((Product) o).getName()+" is added in queue");
           Q.add(o);
        }
    }

    @Override
    public void dequeue() {
        if(Q.size()==0){
            System.out.println("Not have product in queue");
        }else{
            setAmount(getAmount() + ((Product) Q.get(0)).getPrice());
            Q.remove(0);
        }

    
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }
    public double getAmount() {
        return amount;
    }

    
}
