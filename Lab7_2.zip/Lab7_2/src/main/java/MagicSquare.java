/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maou
 */
public class MagicSquare {
    private int[][] square;
    public MagicSquare(int n){
        square = new int[n][n];
        square[n-1][(n-1)/2] = 1;
        int i = n-1; 
        int j = (n-1)/2;
        int k =1;
        for (int r =0;r<n*n-1;r++){
            if (square[i][j] !=0 & i == n-1 && j == n-1){
                i = n-3;
                j = n-2;
            }
            i = (i+1>=square.length? 0:i+1);
            j = (j+1>=square[0].length? 0:j+1);
            if (square[i][j] !=0){
                i-=2;
                j--;
            }
            square[i][j] = k+1;
            k++;
        }
    }
    @Override
    public String toString(){
        String s =  "";
        for (int rows =0;rows < square.length;rows++) {
            for(int column =0;column<square[rows].length;column++){
//                s +=square[rows][column]+"  ";
                s+= String.format("%-6d",square[rows][column]);
            }
            s+="\n\n";
        }
        return s;
    }
    
}
