
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB9_1 ; 
import java.util.ArrayList;
/**
 *
 * @author ADMIN
 */
public class Order {    
           public static int cntOrder = 0; 
           private int id;
           private Customer c ; //data in customer class
           private ArrayList<Pizza> p;
           private double tp = 0 ;  
           private double tpd = 0 ;  
           public void  addPizza(Pizza p) {
                      this.p.add(p);
           }
           public String getOrderDetail() {
                       //double tp = 0 ;  
                       String D = "Order id : " ;
                       this.id = cntOrder ;
                       String num = String.valueOf(id) ;
                       D=D+num+"\n";
                       D=D+c.getName()+" tel "+c.getTel() + "\n" ;
                       for(int i=0; i<p.size();i++){
                                    D = D + p.get(i).getMenu()+" price : "+String.valueOf(p.get(i).getPrice())+p.get(i).getSpecial()+"\n"; 
                                    tp =tp + (p.get(i).getPrice()) ;
                                    tpd = tpd + ((p.get(i).getPrice()) - ( (p.get(i).getPrice()) * (c.getDiscount()) ) ) ;
                        }
                       D = D +"Total pieces : " + p.size() + "\n";
                       D = D + "Total cost : " + tp ;
                      return D ;
            }
           public double calculatePayment(){
               return tpd ;
           }
           public Order(Customer c){
                        this.c = c;
                        cntOrder = cntOrder +  1;
            }
            public String toString(){
                        String u = "";
                        for (Object a : p){
                                    u = u+ a;
                        }
                        return u;
            }

}
