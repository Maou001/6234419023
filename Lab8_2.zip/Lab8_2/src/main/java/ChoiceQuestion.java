
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class ChoiceQuestion extends Question {
    private ArrayList<String> choice;
    public ChoiceQuestion(String text) {
        super(text);
        choice = new ArrayList();
    }
    public void addChoice(String choice,boolean correct){
        this.choice.add(choice);
        if(correct) setAnswer(choice);
    }
    @Override
    public void display(){
        System.out.println(getText());
        for(int i = 0; i< choice.size();i++){
            int num =i+1;
            System.out.println(num+": "+choice.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response){
        int numChoice = Integer.parseInt(response)-1;
        return choice.get(numChoice).equalsIgnoreCase(getAnswer());
    }
}

