/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.lang.Double;
/**
 *
 * @author Maou
 */
public class Line {
    private double m,b,x ;
    public Line(double x, double y, double m) {
        this.x = Double.NaN;
        this.m = m;
        this.b = (m*(-x))+y;
    }
    public Line(double x1, double y1, double x2, double y2){
        this.x = Double.NaN;
        this.m = (y2-y1)/(x2-x1);
        this.b = (m*(-x1))+y1;
    }
    public Line(double m, double b){
        this.x = Double.NaN;
        this.m = m;
        this.b = b;    
    }
    public Line(double a){
        this.x = a;
        this.m = Double.NaN;
        this.b = Double.NaN;
    }
    public boolean isParallel(Line line)
    {
        if (line.m == this.m || (line.m == Double.NaN && this.m == Double.NaN))
                //(Double.isNaN(this.m) & Double.isNaN(line.m))
            return true ;
        else 
            return false ;
    }
    public boolean equals(Line line)
    {
        if ((line.m == this.m || (line.m == Double.NaN && this.m == Double.NaN)) && line.x == this.x && line.b == this.b)
                //(this.x == line.x)
            return true ;
        else         
            return false ;
    }
    public boolean isIntersect(Line line)
    {
        return !this.isParallel(line);
    }
    public Point2D.Double getIntersectionPoint(Line line){
        double PointX = 0;
        double PointY = 0;
        if(Double.isNaN(line.m) & Double.isNaN(line.b)){
            PointX = line.x;
            PointY = (this.m*PointX)+this.b;                  
        }else if(Double.isNaN(line.x) & Double.isNaN(this.x)){
            PointX = (line.b-this.b)/(this.m-line.m);
            PointY = (this.m*PointX)+this.b;
        }else if (Double.isNaN(this.m) & Double.isNaN(this.b)){
            PointX = this.x;
            PointY = (line.m*PointX)+line.b;
        }
        Point2D.Double l = new Point.Double(PointX,PointY);
        return l;
    }	   
}